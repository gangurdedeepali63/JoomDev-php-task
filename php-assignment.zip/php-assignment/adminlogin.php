
<?php
 session_start();
include 'config.php';

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];

	
	$password_hash = password_hash($password, PASSWORD_DEFAULT);

	$sql = "SELECT * FROM admin WHERE username='".$username."'";
	
	$res = $conn->query($sql);
	if(mysqli_num_rows($res) == 1){

		$row = mysqli_fetch_assoc($res);

		if($row['username'] == $username && password_verify($password, $row['password'])){
			 $_SESSION['user_name'] = $username;
       		$_SESSION['logged_in'] = time();
			echo "Login successful! Welcome,".$username;	
			header('location: dashboard.php');

		}else{
			
        	echo "Invalid username or password. Please try again.";
        	$_SESSION['msg'] = 'Invalid username or password. Please try again';
		}
	}

	
}


?>