<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $fields = array('Emp Name', 'Task Date', 'Start time', 'Stop time', 'Notes', 'Description'); 
    $delimiter = ","; 
    $filename = "all-submitted-tasks".date('Y-m-d-H-i-s').".csv"; 
    $f = fopen("php://output", "w");
    
    fputcsv($f, $fields, $delimiter);

    $get_tasks = "select task.*, fname, lname from task INNER JOIN users on task.user_id = users.id;";
    $resulttasks = $conn->query($get_tasks);
    
    while ($row = mysqli_fetch_assoc($resulttasks)) {
    	$ename = $row['fname'].' '.$row['lname'];
    	$row_data = array($ename, $row['task_date'], $row['start_time'], $row['stop_time'], $row['notes'], $row['description']); 
        fputcsv($f, $row_data, $delimiter);


    }
    
    fclose($f);
   
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="'.$filename.'";'); 
    
    exit();
}
?>