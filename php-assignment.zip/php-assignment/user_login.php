<?php

session_start();
include 'config.php';

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];

	
	$password_hash = password_hash($password, PASSWORD_DEFAULT);

	$sql = "SELECT * FROM users WHERE email='".$email."'";
	
	$res = $conn->query($sql);
	if(mysqli_num_rows($res) == 1){

		$row = mysqli_fetch_assoc($res);

		if($row['email'] == $email && password_verify($password, $row['password'])){
			 $_SESSION['user_id'] = $row['id'];
			 $_SESSION['username'] = $row['fname'];
       		$_SESSION['logged_in_user'] = time();
			echo "Login successful! Welcome,".$row['fname'];	
			$query = "SELECT last_login, last_password_change FROM users WHERE id = " .$row['id'];
			
		    $result = $conn->query($query);
		    $user_data = mysqli_fetch_assoc($result);
		    $lastchangepassword = strtotime($user_data['last_password_change']);
		    $todays_date = strtotime(date('Y-m-d H:i:s'));
		   // echo date('Y-m-d H:i:s');
		    //echo '<br>'.$todays_date;
		    $numberofdayspasswordchange = floor((time() - $lastchangepassword) / (60 * 60 * 24));
		    
		    if (!$user_data['last_login'] || $numberofdayspasswordchange > 30) {
		        // Prompt the user to change their password
		        header("Location: update_password.php?id=".$row['id']);
		        exit();
		    }

		    //if not fisrt time login
		    $new_query = "UPDATE users SET last_login = NOW() WHERE id =".$row['id'];
		    $new_result = $conn->query($new_query);
		    header("Location: add_task.php");
    		exit();

		}else{
			
        	echo "Invalid username or password. Please try again.";
        	$_SESSION['msg'] = 'Invalid email address or password. Please try again';
        	header("Location: userlogin.php");
    		exit();
		}
	}

	
}


?>