<?php
include 'config.php';

if (isset($_POST['submit'])) {

	$username = $_POST['username'];
	$password = $_POST['password'];

	$password_hash = password_hash($password, PASSWORD_DEFAULT);


	$existingrow = "select * from admin where username= '".$username."' ";
	
	$resexitsing = $conn->query($existingrow);
	
	
	if(mysqli_num_rows($resexitsing) != 0){
		echo 'Admin user already exist!';
	}else{

		$insert = "INSERT INTO admin (username, password) VALUES ('".$username."', '".$password_hash."')";
		$result = $conn->query($insert);
		echo "Admin account created successfully!";	
		header('location:index.php');

	}

}


?>