<?php

session_start();
include 'config.php';


if (isset($_POST['submit'])) {
	$user_id = $_POST['user_id'];
	$current_password = $_POST['current_password'];
	$new_password = $_POST['new_password'];
	$confirm_password = $_POST['confirm_password'];
	//echo $user_id.'<br>'.$new_password.'<br>'.$confirm_password;

	if ($new_password != $confirm_password) {
        $_SESSION['msg'] = "New password and confirm password do not match.";
        header('Location: update_password.php');
    } else {
        
        $sql = "SELECT password FROM users WHERE id =" .$user_id;
        $res = $conn->query($sql);
        if(mysqli_num_rows($res) == 1){
        	$userpass = mysqli_fetch_assoc($res);

	        if (password_verify($current_password, $userpass['password'])) {
	        	$changedpassword = password_hash($new_password, PASSWORD_DEFAULT);
	        	$updatequery = "update users set password = '".$changedpassword."' , last_password_change = NOW() WHERE id=".$user_id;
	        	//echo $updatequery;exit;
	        	$result = $conn->query($updatequery);
	        	$_SESSION['success'] = "Password updated successfully";
	        	header('Location: userlogin.php');


	        }
    	}
    }
}

?>
