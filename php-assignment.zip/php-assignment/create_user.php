<?php

include 'config.php';

if(isset($_POST['submit'])){

  $fname = $_POST['firstname'];
  $lname = $_POST['lastname'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $password = $_POST['password'];
  $passwordhash = password_hash($password, PASSWORD_DEFAULT);


  $query = "select * from users where email='".$email."' ";
  
  $res = $conn->query($query);

  if(mysqli_num_rows($res) != 0){
    echo 'User already exist!';
  }else{

    $insertuser = "INSERT INTO users (fname, lname, email, phone, password, last_login, last_password_change) VALUES ('".$fname."', '".$lname."', '".$email."', '".$phone."', '".$passwordhash."', now(), '')";

    $result = $conn->query($insertuser);

    echo 'User created successfully!';
    $project = explode('/', $_SERVER['REQUEST_URI'])[1];
    
    $actual_link = "http://$_SERVER[HTTP_HOST]/" . $project . "/userlogin.php";

    $to = $email;
     
    $subject = 'Login Details';
    $email_content = '<html">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      </head>
      <body>

      <div>
              <p>Dear '.$fname.',</p>
              <p>Welcome to the website! Your account has been successfully created. Please <a href ='.$actual_link.'>Click Here</a> to login to your account! </p>
              <p>Here are your login details:</p>
              <p>Email: '.$email.'</p>
              <p>Password: '.$password.'</p>
              <p>Feel free to contact us if you have any questions.</p>
              <p>Best regards,</p>
              <p>Your Website Team,</p>


      </div>
      </body>
      </html>';
         
    
    /*$body = "Dear ".$fname.",\n\n";
    $body .= "Welcome to the website! Your account has been successfully created. Please <a href='" . $actual_link . "'> Click Here </a> to login to your account! \n";
        

    $body .= "Here are your login details:\n";
    $body .= "Email: ".$email."\n";
    $body .= "Password: ".$password."\n";
    $body .= "Feel free to contact us if you have any questions.\n\n";
    $body .= "Best regards,\nYour Website Team";*/
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: webworlddipali@gmail.com' . "\r\n";

// Send email
    if (mail($to, $subject, $email_content, $headers)) {
        echo "Email sent successfully!";
        header('location: users.php');
    } else {
        echo "Email sending failed.";
    }
    
  }
  
}
?>