<?php

session_start();
include 'config.php';

if (isset($_POST['submit'])) {

	$start_time = $_POST['start_time'];
	$stop_time = $_POST['stop_time'];
	$task_date = date("Y-m-d");
	$notes = $_POST['notes'];
	$description = $_POST['description'];
	$userid = $_POST['userid'];

	//echo $userid.'<br>'.$start_time.'<br>'.$stop_time.'<br>'.$task_date.'<br>'.$notes.'<br>'.$description;

	$insert_task = "INSERT INTO task (user_id, start_time, stop_time, task_date, notes, description) VALUES ('".$userid."', '".$start_time."', '".$stop_time."', '".$task_date."', '".$notes."', '".$description."')";
	$taskresult = $conn->query($insert_task);
	$_SESSION['msg'] = 'Task Submitted Successfully';
	header('Location:add_task.php');

}

?>